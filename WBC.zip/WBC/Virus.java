import greenfoot.*;

/**
 * Virus will show up randomly on left of screen, and rotate.
 * 
 * @author (Jim Turner Jr) 
 * @version (11/4/2015)
 */
public class Virus extends Actor
{
    /**
     * Act - do whatever the Virus wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        setLocation(getX()-8, getY());
        turn(1);
        
        if (getX() == 0) 
        {
            getWorld().removeObject(this);
        }
    }    
}
