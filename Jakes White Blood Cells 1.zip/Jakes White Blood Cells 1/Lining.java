import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * The Lining are objects at the edge of the vein.
 * 
 * @author Michael Kölling
 * @version 0.1
 * 
 * The vein that holds a stream of blood!!!
 */
public class Lining extends Actor
{
    /**
     * Act - lining moves from right to left, then disappears.
     */
    public void act() 
    {        setLocation(getX()-2, getY());
             move(1);
             
             if (getX() == 0) 
        {
            getWorld().removeObject(this);
        }
    }
}

