import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * This is a white blood cell. This kind of cell has the job to catch 
 * bacteria and remove them from the blood.
 * 
 * @author Michael Kölling
 * @version 0.1
 * 
 * Circular cells that keep mammals from getting sick.
 */
public class WhiteCell extends Actor
{
    private int score;
    
    /**
     * Act: move up and down when cursor keys are pressed.
     */
    public void act() 
    {
        checkKeyPress();
        checkCollision();
    }
    
    /**
     * Check whether a keyboard key has been pressed and react if it has.
     */
    private void checkKeyPress()
    {
        if (Greenfoot.isKeyDown("up")) 
        {
            setLocation(getX(), getY()-4);
        }
        
        if (Greenfoot.isKeyDown("down")) 
        {
            setLocation(getX(), getY()+4);
        }
    }
    
    /**
     * Check whether a bacteria is touching.
     */
    private void checkCollision()
    {
        if (isTouching(Bacteria.class))
        {
            Greenfoot.playSound("slurp.wav");
            removeTouching(Bacteria.class);
            score = score + 20;
            getWorld().showText("Score: " + score, 80, 25);
        }
        
        if (isTouching(Virus.class))
        {
            Greenfoot.playSound("game-over.wav");
            Greenfoot.stop();
        }
    }
}

